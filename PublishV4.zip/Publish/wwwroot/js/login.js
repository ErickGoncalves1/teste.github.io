const menuBars = document.querySelector(".menu-bars")
const menu = document.querySelector(".menu")
const item = document.querySelector(".item")
const itemAll = document.querySelectorAll(".item")

menuBars.addEventListener('click',(e)=>{
    menu.classList.toggle('open')
})


itemAll.forEach((el)=>{
    el.addEventListener('click', function(e){
        itemAll.forEach((elemento)=>{
            console.log('removendo')
            elemento.classList.remove('active')
        })
        this.classList.add('active')
    })  
})
